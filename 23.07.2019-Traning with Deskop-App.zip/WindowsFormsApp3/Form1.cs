﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3.Properties
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
 
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (Book book in BookList.GetBooks)
            {
                lbBooks.Items.Add(book.Name);
            }
            foreach (Ganre ganre in GanreLIst.GetGanres())
            {
                cmbGanrs.Items.Add(ganre.Name);
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string ganrName = cmbGanrs.Text.Trim().ToLower();
            string bookName = txtBookName.Text.Trim();
            if (bookName == "")
            {
                MessageBox.Show("Book name is Empty", "Eror", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (ganrName == "")
            {
                MessageBox.Show("Ganre sholud be selected", "Eror", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            string selectedGanrId = GanreLIst.GetGanreIdByName(ganrName);
            Book newBook = new Book { Name = bookName, GanreId = selectedGanrId };
            BookList.AddBook(newBook);
            lbBooks.Items.Clear();
            txtBookName.Text = "";
            foreach (Book book in BookList.GetBooks)
            {
                lbBooks.Items.Add(book.Name);
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string serchByBookName = txtSearchByBookName.Text.Trim().ToLower();
            lbBooks.Items.Clear();
            txtSearchByBookName.Text = "";
            int searchCount = 0;
            foreach (Book book in BookList.GetBooks)
            {
                if (book.Name.Trim().ToLower() == serchByBookName)
                {
                    lbBooks.Items.Add(book.Name);
                    searchCount++;
                }

            }
            if(searchCount == 0)
            {
             MessageBox.Show("This book hav'nt our library", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);  
            }
        }
    }
}
