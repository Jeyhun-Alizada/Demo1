﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp6
{
    public static class FilmList
    {
        private static HashSet<Film> films = new HashSet<Film>
        {
            new Film {Name="Yuksek gerilim", GanreId=GanreList.GetIdByGanrenName("Elmi fantastika")},
            new Film {Name="Celal ve Ceren", GanreId=GanreList.GetIdByGanrenName("Komediya")},
            new Film {Name="Atesh ve Su", GanreId=GanreList.GetIdByGanrenName("Romantika")},
            new Film {Name="Qisqiriq", GanreId=GanreList.GetIdByGanrenName("Qorxulu")},
            new Film {Name="Lusi", GanreId=GanreList.GetIdByGanrenName("Elmi fantastika")},
            new Film {Name="Guldur guldur", GanreId=GanreList.GetIdByGanrenName("Komediya")}
        };
        public static IEnumerable<Film> GetFilms => films;
        public static void AddFilm(Film filmName)
        {
            films.Add(filmName);
        }
    }
}
