﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp4
{
    public static class GanreList
    {
        private static HashSet<Ganre> ganres = new HashSet<Ganre>
        {
            new Ganre {Name="Bedii" },
            new Ganre {Name="Elmi"},
            new Ganre {Name ="Dedektiv"}
    };
        public static IEnumerable<Ganre> GetGanres() => ganres;
        public static void AddGanre(Ganre g)
        {
            ganres.Add(g);
        }
        public static string GetGanrIdByName(string ganrName)
        {
            foreach (Ganre ganre in ganres)
            {
                if (ganre.Name.Trim().ToLower() == ganrName.Trim().ToLower()){
                    return ganre.Id;
                }
            }
            return null;
        }

    }
 
}
