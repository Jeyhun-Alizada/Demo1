﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3.Properties
{
    public static class BookList
    {
        private static List<Book> books = new List<Book>
        {
            new Book { Name = "Sefiller", GanreId = GanreLIst.GetGanreIdByName("Bedii")},
            new Book { Name = "C#", GanreId = GanreLIst.GetGanreIdByName("Elmi")},
            new Book { Name = "Qan lekesi", GanreId = GanreLIst.GetGanreIdByName("Dedektiv")},
            new Book { Name = "Kimyager", GanreId = GanreLIst.GetGanreIdByName("Bedii")}
        };

       public static List<Book> GetBooks => books;
        public static void AddBook(Book bookName)
        {
            books.Add(bookName);
        }

    }
}
