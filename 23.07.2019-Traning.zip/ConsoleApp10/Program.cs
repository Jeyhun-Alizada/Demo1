﻿using System;

namespace ConsoleApp10
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("How many contact you want add?");
            int ContactCount = int.Parse(Console.ReadLine());
            Contact[] phoneBook = new Contact[ContactCount];
            for (int i = 0; i < ContactCount; i++)
            {
                phoneBook[i] = new Contact();
                Console.WriteLine($"Please, input Name for {i + 1}-th contact.");
                string inputName = Console.ReadLine();
                phoneBook[i].Name = inputName;
                Console.WriteLine($"Please, input Number for {i + 1}-th contact.");
                string inputNumber = Console.ReadLine();
                phoneBook[i].Phone = inputNumber;
            }
            Console.WriteLine("\n\n");
            foreach (Contact contact in phoneBook)
            {
                Console.WriteLine($"{contact.Name}\n{contact.Phone}");
            }

            Console.WriteLine("\n\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Input 1 for serach bay name or input 2 for search by number");
            int searchMethod = int.Parse(Console.ReadLine());
            if (searchMethod == 1)
            {
                int searchCount = 0;
                Console.WriteLine("Please input somethink for seach.");
                string seachInputByName = Console.ReadLine().Trim().ToLower();
                foreach (Contact contact in phoneBook)
                {
                    if (contact.Name.Contains(seachInputByName))
                    {
                        Console.WriteLine(" \n\n ");
                        Console.WriteLine($"{contact.Name}\n{contact.Phone}");
                    };
                    searchCount++;
                }
                Console.WriteLine();
                if (searchCount == 0) Console.WriteLine("Not found.");
            }
            else if (searchMethod == 2)
            {
                int searchCount = 0;
                Console.WriteLine("Please input number for seach.");
                string seachInputByNumber = Console.ReadLine().Replace(" ", "").Replace("-", "");
                foreach (Contact contact in phoneBook)
                {
                    if (contact.Phone.Replace(" ", "").Replace("-", "") == seachInputByNumber)
                    {
                        Console.WriteLine(" \n\n ");
                        Console.WriteLine($"{contact.Name}\n{contact.Phone}");
                    };
                    searchCount++;
                }
                Console.WriteLine();
                if (searchCount == 0) Console.WriteLine("Not found.");
            }
            else
            {
                Console.WriteLine("SearchMethod method is invalid.");
            }
            Console.ReadKey();
        }
        class Contact
        {
            private string _name;

            public string Name
            {
                get => _name;
                set
                {
                    if (value.Length > 2)
                    { _name = value; }
                    else { throw new ArgumentException("Name is so short."); }
                }
            }
            private string _phone;
            public string Phone
            {
                get => _phone;
                set
                {
                    if (value.IndexOf('+') != -1)
                    { _phone = value; }
                    else { throw new ArgumentException("Number is invalid."); }
                }
            }
        }
    }
}
