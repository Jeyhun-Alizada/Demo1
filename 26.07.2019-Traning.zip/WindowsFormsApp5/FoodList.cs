﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp5
{
    public class FoodList
    {
        public static HashSet<Food> foods = new HashSet<Food>
        {
            new Food() {Name = "Doner", Calori = 450, Price=2},
            new Food() {Name = "Lahmacun", Calori = 350, Price=3},
            new Food() {Name = "Pizza", Calori = 600, Price=12},
            new Food() {Name = "Merci", Calori = 300, Price=2},
            new Food() {Name = "Ayran", Calori = 150, Price=1},
            new Food() {Name = "Mimoza", Calori = 275, Price=3},
            new Food() {Name = "Fanta", Calori = 400, Price=1},
            new Food() {Name = "Dolma", Calori = 425, Price=5},
            new Food() {Name = "Su", Calori = 0, Price=1},
        };

        public static HashSet<Food> GetFoods() => foods;
    }
}
