﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3.Properties
{
    public static class GanreLIst
    {
        private static HashSet<Ganre> ganres = new HashSet<Ganre>
        {
            new Ganre {Name="Bedii"},
            new Ganre {Name="Elmi"},
            new Ganre {Name="Dedektiv"}
        };

        public static IEnumerable <Ganre> GetGanres()
        {
            return ganres;
        }
        public static void AddGanre(Ganre g)
        {
            ganres.Add(g);
        }
        public static string GetGanreIdByName(string ganrName)
        {
            foreach (Ganre ganre in ganres)
            {
                if(ganre.Name.ToLower()== ganrName.ToLower())
                {
                    return ganre.Id;
                }
            }
            return null;
        }
    }
}
