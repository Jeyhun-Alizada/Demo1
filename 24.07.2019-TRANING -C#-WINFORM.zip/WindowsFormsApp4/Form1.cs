﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (Ganre ganre in GanreList.GetGanres())
            {
                cmbGanre.Items.Add(ganre.Name);
            }
            foreach (Book book in BookList.GetBooks())
            {
                lbBook.Items.Add($"{book.Name}-{book.Id}-{book.GanreId}");
            }
        }

        private void CmbGanre_SelectedIndexChanged(object sender, EventArgs e)
        {
          
            lbBook.Items.Clear();
            foreach (Book book in BookList.GetBooks())
            {
                if (book.GanreId == GanreList.GetGanrIdByName(cmbGanre.Text))
                {
                    lbBook.Items.Add($"{book.Name}-{book.Id}-{book.GanreId}");
                }
            }

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            lbBook.Items.Clear();
            string ganreName = cmbGanre.Text;
            string bookName = txtBookName.Text.Trim();
            if(bookName!= "" && ganreName !="")
            {
                Book newBook = new Book { Name = bookName, GanreId = GanreList.GetGanrIdByName(ganreName) };
                BookList.AddBook(newBook);
            }
            else { MessageBox.Show("Book name is so short or Ganre type not selected.","Info:",MessageBoxButtons.OK,MessageBoxIcon.Information); }
            foreach (Book book in BookList.GetBooks())
            {
                lbBook.Items.Add($"{book.Name}-{book.Id}-{book.GanreId}");
            }
            txtBookName.Text = "";
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string findBook = txtBookFind.Text.Trim().ToLower();
            int findCounter = 0;
            foreach (Book book in BookList.GetBooks())
            {
                if (findBook == book.Name.Trim().ToLower())
                {
                    lbBook.Items.Clear();
                    lbBook.Items.Add($"{book.Name}-{book.Id}-{book.GanreId}");
                    findCounter++;
                    txtBookFind.Text = "";
                }
            }
            if (findCounter == 0) 
                {
                    MessageBox.Show("Sorry. This book havn't our library", "Info:", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            
        }

        private void LbBook_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
