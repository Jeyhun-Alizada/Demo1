﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (Ganre ganre in GanreList.GetGanres)
            {
                cmbGanreList.Items.Add(ganre.Name);
            }
            foreach (Film  film in FilmList.GetFilms)
            {
                lbFilm.Items.Add(film.Name);
            }
        }
        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbFilm.Items.Clear();
            foreach (Ganre ganre in GanreList.GetGanres)
            {
                if (cmbGanreList.Text==ganre.Name)
                {
                    foreach (Film film in FilmList.GetFilms)
                    {
                        if (ganre.Id == film.GanreId)
                        {
                            lbFilm.Items.Add(film.Name);

                        }
                    }
                }
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string filmName = txtBook.Text.Trim();
            string ganrName = cmbGanreList.Text;
            Film newFilm= new Film { Name = filmName, GanreId = GanreList.GetIdByGanrenName(ganrName) };
            FilmList.AddFilm(newFilm);
            txtBook.Text = "";
            lbFilm.Items.Clear();
            foreach (Ganre ganre in GanreList.GetGanres)
            {
                if (cmbGanreList.Text == ganre.Name)
                {
                    foreach (Film film in FilmList.GetFilms)
                    {
                        if (ganre.Id == film.GanreId)
                        {
                            lbFilm.Items.Add(film.Name);

                        }
                    }
                }
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            lbFilm.Items.Clear();
            foreach (Film film in FilmList.GetFilms)
            {
                if (txtSearch.Text.Trim().ToLower() == film.Name.Trim().ToLower())
                {
                    lbFilm.Items.Add(film.Name);
                }
            }
            txtSearch.Text = "";
        }
    }
}
