﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp4
{
    public class Ganre
    {
        private static int _counter = 1;
        public string Name { get; set; }
        public string Id { get; private set; }

        public  Ganre()
        {
            Id = new string('0', 3 - _counter.ToString().Length) + _counter;
            _counter++;
        }
    }
}
