﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp6
{
   public class Ganre
    {
        private static int _idCounter =1000;
        public string Id { get; private set; }
        public string Name { get; set; }
        public  Ganre()
        {
            Id = new string('0', 6 - _idCounter.ToString().Length) + _idCounter;
            _idCounter++;
        }
    }

}
