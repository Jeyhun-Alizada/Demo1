﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp5
{
   public class Food
    {
        private static int _counter = 1;
        public string Name { get; set; }
        public string Id { get; private set; }
        public decimal Calori { get; set; }
        public decimal Price { get; set; }

        public Food()
        {
            Id = new string('0', 6 - _counter.ToString().Length) + _counter;
            _counter++;
        }
    }
}
