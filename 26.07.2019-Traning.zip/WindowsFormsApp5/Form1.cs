﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Kulinariya : Form
    {
        public Kulinariya()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (Food food in FoodList.GetFoods())
            {
                lbFood.Items.Add($"{food.Id}-{food.Name}-{food.Price} AZN -{food.Calori} KKAL");
            }
        }
        public decimal caloritotal = 0;
        public decimal sumtotal = 0;
        
        private void LbFood_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbSelectedClient.Items.Add(lbFood.SelectedItem.ToString());
            string replaceSelectI= lbFood.SelectedItem.ToString().Replace(" ", "").Replace("-", "").Replace("0","").Replace("1", "").Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "");
            foreach (Food food in FoodList.GetFoods())
            {
                if (replaceSelectI == food.Name+"AZNKKAL")
                {
                    caloritotal = caloritotal + food.Calori;
                    sumtotal = sumtotal + food.Price;
                }
            }
            lbTotalSumClient.Items.Clear();
            lbTotalSumClient.Items.Add("Cemi kalori: "+caloritotal+"KKAL");
            lbTotalSumClient.Items.Add("Cemi mebleg: " + sumtotal +"AZN");
        }

        private void LbSelectedClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbSelected.Items.Clear();
            lbSelectedClient.Items.Remove(lbSelectedClient.SelectedItem) ;
            #region with HashSet
            //foreach (var item in lbSelectedClient.Items)
            //{
            //    HashSet<OrderList> myhashSet = new HashSet<OrderList>
            //    {
            //        new OrderList{ Info= item.ToString()}
            //    };
            //    foreach (var order in myhashSet)
            //    {
            //        lbSelected.Items.Add(order.Info);
            //    }
            //}
            #endregion
            #region with Items.Add
            foreach (var item in lbSelectedClient.Items)
            {
                lbSelected.Items.Add(item.ToString());
            }
            #endregion
        }
    }
}
