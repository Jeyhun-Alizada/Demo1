﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp4
{
    public class BookList
    {
        private static HashSet<Book> books = new HashSet<Book>
        {
            new Book { Name = "Sefiller", GanreId = GanreList.GetGanrIdByName("Bedii") },
            new Book { Name = "C# 8.00", GanreId = GanreList.GetGanrIdByName("Elmi") },
            new Book { Name = "Qan Lekesi", GanreId = GanreList.GetGanrIdByName("Dedektiv") },
            new Book { Name = "Sicanlar ve adamlar", GanreId = GanreList.GetGanrIdByName("Bedii") },
            new Book { Name = "HTML 5", GanreId = GanreList.GetGanrIdByName("Elmi") },
            new Book { Name = "Kimyager", GanreId = GanreList.GetGanrIdByName("Bedii") }
        };

            public static void AddBook(Book bookName)
        {
            books.Add(bookName);
        }

        public static IEnumerable<Book> GetBooks() => books;
    };
}
