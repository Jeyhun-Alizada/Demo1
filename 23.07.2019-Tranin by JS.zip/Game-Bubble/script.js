"use strict;"
const buubleZone = document.getElementById("bubbleZone");
let score =0;
let myInterval;
$(".start").click(function(){
myInterval =setInterval(() => {
let bubble = document.createElement("div");
bubble.classList.add("bubble");
buubleZone.appendChild(bubble);
bubble.style.top=Math.round(Math.random()*80)+ "%";
bubble.style.left=Math.round(Math.random()*80)+ "%";
bubble.onclick =function(){
    const sound = new Audio("bubble.mp3");
    sound.play();
    this.remove();
    score++;
    $(".score").text(score);
}
},1500);
});
$(".stop").click(function(){
clearInterval(myInterval);
});