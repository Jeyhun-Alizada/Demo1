﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp6
{
    public static class GanreList
    {
      private static  HashSet<Ganre> ganres = new HashSet<Ganre>
        {
            new Ganre { Name = "Elmi fantastika" },
            new Ganre { Name = "Romantika" },
            new Ganre { Name = "Komediya" },
            new Ganre { Name = "Qorxulu" }
        };
        public static IEnumerable<Ganre> GetGanres => ganres;
        public static string GetIdByGanrenName(string ganreName)
        {
            foreach (Ganre ganre in GanreList.GetGanres)
            {
                if (ganre.Name == ganreName)
                {
                    return ganre.Id;
                }
            }
            return null;
        }
    };
}
